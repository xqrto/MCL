# Konfiguration
$nrSource = "xylon\nr"
$nrTexSource = "xylon\tex\nr"
$versionRoot = Join-Path $env:APPDATA ".minecraft_bedrock\versions"

function Copy-VersionFiles($sourceDir) {
    Get-ChildItem -Path $versionRoot -Directory | ForEach-Object {
        $target = $_.FullName
        Write-Host "Kopiere Dateien von '$sourceDir' nach '$target'"
        Copy-Item -Path "$sourceDir\*" -Destination $target -Recurse -Force
    }
}

function Copy-TexToVanilla($sourceTex) {
    Get-ChildItem -Path $versionRoot -Directory | ForEach-Object {
        $resourcePackPath = Join-Path $_.FullName "data\resource_packs"
        if (Test-Path $resourcePackPath) {
            Get-ChildItem -Path $resourcePackPath -Directory | Where-Object { $_.Name -like "vanilla*" } | ForEach-Object {
                $dest = $_.FullName
                Write-Host "Kopiere Texturen von '$sourceTex' nach '$dest'"
                Copy-Item -Path "$sourceTex\*" -Destination $dest -Recurse -Force
            }
        }
    }
}

Write-Host "Starte Kopieren der NR-Dateien..."
Copy-VersionFiles -sourceDir $nrSource
Copy-TexToVanilla -sourceTex $nrTexSource
Write-Host "NR-Dateien erfolgreich kopiert."
