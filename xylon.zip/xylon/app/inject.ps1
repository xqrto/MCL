# Konfiguration
$xySource = "xylon\xy"
$xyTexSource = "xylon\tex\xy"
$versionRoot = Join-Path $env:APPDATA ".minecraft_bedrock\versions"

function Copy-VersionFiles($sourceDir) {
    Get-ChildItem -Path $versionRoot -Directory | ForEach-Object {
        $target = $_.FullName
        Write-Host "Kopiere Dateien von '$sourceDir' nach '$target'"
        Copy-Item -Path "$sourceDir\*" -Destination $target -Recurse -Force
    }
}

function Copy-TexToVanilla($sourceTex) {
    Get-ChildItem -Path $versionRoot -Directory | ForEach-Object {
        $resourcePackPath = Join-Path $_.FullName "data\resource_packs"
        if (Test-Path $resourcePackPath) {
            Get-ChildItem -Path $resourcePackPath -Directory | Where-Object { $_.Name -like "vanilla*" } | ForEach-Object {
                $dest = $_.FullName
                Write-Host "Kopiere Texturen von '$sourceTex' nach '$dest'"
                Copy-Item -Path "$sourceTex\*" -Destination $dest -Recurse -Force
            }
        }
    }
}

Write-Host "Starte Kopieren der XY-Dateien..."
Copy-VersionFiles -sourceDir $xySource
Copy-TexToVanilla -sourceTex $xyTexSource
Write-Host "XY-Dateien erfolgreich kopiert."
